ZLPLL Firmware version 3.1G

Updated build with correct complier options selected.
28/4/2017


Revision History
// Rev 3.0
// Rev 3.1
//
// Rev 3.1A 	WDK	20-Jan-2013
//	- Change sense of oscillator select output to cater for added BC847
//	  Inverter driving the oscillator power switch.
//      - Allow space in command (ie F 2200)
//
//	PCB includes pins to take lock and ext signals to external LED's
//
// Rev 3.1B	WDK	10-Mar-2013
//	- Restructure to allow for Beacon ID version
//	- Internal version only
//
// Rev 3.1C     WDK     23-Mar-2013
//      - Multiple channel support
//	- Fixed bugs with I/O pins
//	- Stopped transmitting when text entered
//	- Test for bad messages, ie [0] by itself which looped!
//
// Rev 3.1D	WDK	3-Oct-2013
//	- Frequency set to 0 MHz enables external PLL
//	  support for connection to Multi Beacon Controller (MBC)
//      - Channel spacing (N) chnaged from MHz to Hz
//
//      - Add V command for setting the RDIV value
//      - Set E to 0 to disable external ref selection
//      - Set R to 0 to disable internal ref selection
//        NB.  Power cycle may be required to change clock modes
//
//  Rev 3.1E 
//		- Improve soft UART receiver to sample data in middle of bit. Fixed issue with
//		  corrupted data on input 
//		- EXT_THRESHOLD improvements to avoid false triggering of external clock 
//		- From S/N 200 (excl 201 and 206) plus S/N 184E 
//
//  Rev 3.1F
//		- Add extra stop bit to support PL2303TX USB/RS232 interface
//		- Change TX output mode to better handle the reading of the channel offset (+8 to the channel)
//
//  Rev 3.1G	29-Mar-2017
//		- Fixup serial I/O issues when external reference is active
//		- Flash AUX LED 3 times at startup
//		- Watchdog timer changed from 500ms to 2 sec

